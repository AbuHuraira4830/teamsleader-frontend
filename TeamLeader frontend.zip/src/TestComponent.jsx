import React from "react";

const TestComponent = () => {
  return (
    <div style={{ backgroundColor: "red", height: "50px", color: "white" }}>
      Test Component
    </div>
  );
};

export default TestComponent;
