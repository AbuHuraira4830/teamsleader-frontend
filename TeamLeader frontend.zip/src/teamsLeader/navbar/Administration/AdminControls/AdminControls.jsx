import React from "react";
import ColorToggleButton from "../../../Admins/ToggleAdmins";
const AdminControls = () => {
  return (
    <div className="overview ">
      <ColorToggleButton />
    </div>
  );
};

export default AdminControls;
