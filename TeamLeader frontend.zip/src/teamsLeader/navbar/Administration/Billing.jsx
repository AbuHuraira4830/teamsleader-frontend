import React from "react";
import ToggleBillingOptions from "./Billings/ToggleBillingOptions";

const Billing = () => {
  return (
    <div className="overview ">
      <ToggleBillingOptions />
    </div>
  );
};

export default Billing;
