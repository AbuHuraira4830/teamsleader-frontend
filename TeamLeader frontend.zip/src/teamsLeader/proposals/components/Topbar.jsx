import React from 'react'

const Topbar = () => {
  return <div className="topbar bg-white h-16 border-b  rounded-tl-md"></div>;
}

export default Topbar